﻿using System;

namespace Closest_Two_Points
{
    public class Point
    {
        public int X { get; set; }

        public int Y { get; set; }
    }
}
