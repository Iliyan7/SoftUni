﻿using System.Collections.Generic;

namespace TeamworkProjects
{
    public class Team
    {
        public string TeamName { get; set; }
        public List<string> Members { get; set; }
        public string CreatorName { get; set; }
    }
}
