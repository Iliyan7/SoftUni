﻿using System;
using System.Collections.Generic;

namespace MentorGroup
{
    public class Student
    {
        public DateTime[] DatesAttended { get; set; }
        public List<string> Comments { get; set; }
    }
}
