﻿namespace Circles_Intersection
{
    public class CircleProp
    {
        public int X { get; set; }

        public int Y { get; set; }

        public int Radius { get; set; }
    }
}
